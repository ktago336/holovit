
<input class="form-control required", id="check_number", type="text" value="" placeholder="Enter right otp">
<p>Inserted wrong OTP</p>
<a href="javascript:void(0);" id="verify" style="display:none" >Verify</a>

