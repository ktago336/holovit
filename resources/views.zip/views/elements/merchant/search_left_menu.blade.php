<div class="col-md-4 col-sm-4 col-lg-3">

                      <div class="card-main1">
                       <p class="cat12">Categories</p>
                       <?php //$count = 0; ?>
 

 
                       <div class="question_button_sec" id="question_button_sec">

                                <a class="righ_0 collapsed" for="address" data-toggle="collapse" data-target="#collapsetwo" aria-controls="collapseOne" aria-expanded="false">category1
                                <span>10</span>
                                </a>
                            <input type="hidden" value="" id="" name="parent_id">

                            </div>
 

                            <div id="collapsetwo" class="one collapse " data-parent="#accordion" style="">
                                
                                <div class="question_form_sec" id="question_form_sec">
                              
                                    <label class="subcat_check full-width deltimesub" style="">
                                  
                <input id="testsub" type="radio" name="subcategory_id" value="" class="deltimesub"><span class="txt-primary padding-left-xs" id="show_sub_cat_products">Subcategory1</span>
                 <input type="hidden" value="" id="" name="subsubcat_id"> 
                
                <span class="count flt-right">10</span>
              </span>
            </label>
                                 </div>  
                                
                                  
                            </div>


  
 
                             <p class="cat12">Location</p>
                             <div class="serch">
							 {{Form::search('search_location', null, ['class'=>'form-group form-control ng-untouched ng-pristine ng-valid', 'placeholder'=>'Search for a location', 'id'=>'search_location'])}}
                                                          <!--<input class="form-group form-control ng-untouched ng-pristine ng-valid" placeholder="Search for a location" type="search">-->
                           </div>	
						
                          
                          <!-- <div class="question_button_sec result" id="question_button_sec">

                                <a class="righ_0 collapsed" for="address" data-toggle="collapse" data-target="#collapsethree" aria-controls="collapseOne" aria-expanded="false"> New Delhi
                                <span>(205)</span>
                                </a>

                            </div>-->
                            <div id="collapsethree" class="one" data-parent="#accordion" style="">
                                <div class="question_form_sec" id="question_form_sec">
                             <ul class="list-block">
          <li>
            <label class="nb-checkbox full-width">
              <input name="location" type="checkbox" class="ng-pristine ng-valid ng-touched">
              <div class="nb-checkbox__bg">
                <div class="nb-checkbox__icon"></div>
              </div>
              <span class="txt-primary padding-left-xs">Janakpuri
                <span class="count flt-right">(17)</span>
              </span>
            </label>
          </li><li>
            <label class="nb-checkbox full-width">
              <input name="location" type="checkbox" class="ng-untouched ng-pristine ng-valid">
              <div class="nb-checkbox__bg">
                <div class="nb-checkbox__icon"></div>
              </div>
              <span class="txt-primary padding-left-xs">Malviya Nagar
                <span class="count flt-right">(13)</span>
              </span>
            </label>
          </li><li>
            <label class="nb-checkbox full-width">
              <input name="location" type="checkbox" class="ng-untouched ng-pristine ng-valid">
              <div class="nb-checkbox__bg">
                <div class="nb-checkbox__icon"></div>
              </div>
              <span class="txt-primary padding-left-xs">Pitampura
                <span class="count flt-right">(12)</span>
              </span>
            </label>
          </li><li>
            <label class="nb-checkbox full-width">
              <input name="location" type="checkbox" class="ng-untouched ng-pristine ng-valid">
              <div class="nb-checkbox__bg">
                <div class="nb-checkbox__icon"></div>
              </div>
              <span class="txt-primary padding-left-xs">Lajpat Nagar 2
                <span class="count flt-right">(11)</span>
              </span>
            </label>
          </li><li>
            <label class="nb-checkbox full-width">
              <input name="location" type="checkbox" class="ng-untouched ng-pristine ng-valid">
              <div class="nb-checkbox__bg">
                <div class="nb-checkbox__icon"></div>
              </div>
              <span class="txt-primary padding-left-xs">Vikaspuri
                <span class="count flt-right">(10)</span>
              </span>
            </label>
          </li>
        </ul>
                               
                                 </div>  
                                 <a class="view-more font-xs txt-brand-primary">+ View More</a>

                            </div>
                      </div>  
                    </div>

   