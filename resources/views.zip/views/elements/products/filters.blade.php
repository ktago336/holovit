                            <ul class="nav nav-tabs">
    <li class="active"><a data-toggle="tab" href="#home">Near me</a></li>
    <li class=""><a data-toggle="tab" href="#menu1">Popular</a></li>
     <li><a data-toggle="tab" href="#menu2">Whats New</a></li>
       <li><a data-toggle="tab" href="#menu3">Price(High to Low)</a></li>
       <li><a data-toggle="tab" href="#menu4">Price(Low to High)</a></li>
        <li><a data-toggle="tab" href="#menu5">Sale</a></li>
         <li><a data-toggle="tab" href="#menu6">Flowers & More</a></li>
<!--         <li><a data-toggle="tab" href="#menu7">Health & Fitness</a></li>-->
   
  </ul>