<nav class="tab_groupn">
    <div class="nav nav-tabs" id="nav-tab" role="tablist">
        <a class="nav-item nav-link " id="nav-home-tab" data-toggle="tab" href="#nav-groupons" role="tab" aria-controls="nav-home" aria-selected="true">ACCOUNT MY GROUPONS</a>
        <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-deals" role="tab" aria-controls="nav-profile" aria-selected="false">MY GROUPON+ DEALS</a>
        <a class="nav-item nav-link" id="nav-contact-tab" data-toggle="tab" href="#nav-reservtions" role="tab" aria-controls="nav-contact" aria-selected="false"> MY RESERVATIONS</a>
        <a class="nav-item nav-link active" id="nav-contact-tab" data-toggle="tab" href="#nav-account" role="tab" aria-controls="nav-contact" aria-selected="false">ACCOUNT</a>
        <a class="nav-item nav-link " id="nav-contact-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-contact" aria-selected="false">Profile </a>
        <a class="nav-item nav-link" id="nav-contact-tab" data-toggle="tab" href="#nav-select" role="tab" aria-controls="nav-contact" aria-selected="false">GROUPON SELECT</a>
    </div>
</nav>