@extends('layouts.inner')
@section('content')
<section class="my_wishlist">
  <div class="container">
    <div class="row">
     <div class="text">
        <p>My Wishlist</p>
    </div>
    </div>
    <div class="row item">
      <div class="col-md-6">
       <p>Item</p>
      </div>
      <div class="col-md-6">
      <p>Unit Price</p>
      </div>
    </div>
  <div class="row img_text">
    <div class="col-md-6">
      <div class="images_withtext">
      <div class="images-section">
        <img src="http://192.168.0.251:85/comp212/groupon_clone/site/public/files/product/small/e6641ab8_flower4.jpeg" alt="">
      </div>
      <div class="itemDetails columns nine">
      <div class="itemTitle">
          H&amp;R Block
      </div>
            <div class="itemExpires c-txt-black">Ends in 16 days</div>
        <div class="option-title">
          $25 Off In-Store Tax Preparation Services with a Tax Professional from H&amp;R Block
          
        </div>
    </div>
    </div>
    </div>
    <div class="col-md-6">
      <div class="price_delete">
      <span class="regular-price">
       <span class="price">‎ ‎₹155.00</span> 
        <span class="price1">‎ ‎₹15.99</span>
                      </span>
             <div class="delete">
               <a href=""><i class="fa fa-trash-o" aria-hidden="true"></i></a>
             </div>         
                      </div>
    </div>
  </div>
  <div class="row img_text">
    <div class="col-md-6">
      <div class="images_withtext">
      <div class="images-section">
        <img src="http://192.168.0.251:85/comp212/groupon_clone/site/public/files/product/small/e6641ab8_flower4.jpeg" alt="">
      </div>
      <div class="itemDetails columns nine">
      <div class="itemTitle">
          H&amp;R Block
      </div>
            <div class="itemExpires c-txt-black">Ends in 16 days</div>
        <div class="option-title">
          $25 Off In-Store Tax Preparation Services with a Tax Professional from H&amp;R Block
          
        </div>
    </div>
    </div>
    </div>
    <div class="col-md-6">
      <div class="price_delete">
      <span class="regular-price">
       <span class="price">‎ ‎₹155.00</span> 
        <span class="price1">‎ ‎₹15.99</span>
                      </span>
             <div class="delete">
               <a href=""><i class="fa fa-trash-o" aria-hidden="true"></i></a>
             </div>         
                      </div>
    </div>
  </div>
   
    </div>
  
</section>







@endsection